<?php
    header("location: view/pageone.php");
?>