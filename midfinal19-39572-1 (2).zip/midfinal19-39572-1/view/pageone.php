
<?php
include('../control/checkone.php');

if(isset($_SESSION['username']))
{
header("location: pagetwo.php");
}
?>
<!DOCTYPE html>
<html>
<body>

<h1> Personal Details </h1>

<form action="" method="post">
    First Name: <br>
    <input type="text" name="fname">
    <br>
  
    Last Name: <br>
    <input type="text" name="lname">
    <br>
    
    Email: <br>
    <input type="text" name="email">
    <br>
    
    Username: <br>
    <input type="text" name="uname">
    <br>
    
    Password: <br>
    <input type="password" name="password">
    <br>
    
    Website: <br>
    <input type="text" name="website">
    <br>

<p>Select Gender:</p>
  <input type="radio" id="male" name="gender" value="male">
  <label for="male">Male</label><br>
  <input type="radio" id="female" name="gender" value="female">
  <label for="female">Female</label><br>
  <br>

  <input type="submit" value="SUBMIT">
  <input type="reset" value="RESET">
</form>
<br>
<?php echo $error; ?>

</body>
</html>